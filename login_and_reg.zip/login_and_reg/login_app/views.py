from django.shortcuts import render, HttpResponse, redirect
from .models import User
from django.contrib import messages
import bcrypt

def index(request):
    return render(request, "index.html")

def create_user(request):
    errors = User.objects.basic_validator(request.POST)
    if errors:
        for key, value in errors.items():
            messages.error(request,value)
        return redirect('/')
    
    if User.objects.filter(email=request.POST['email']):
        errors['used_email'] = "Email in use"
        for key, value in errors.items():
            messages.error(request,value)
        return redirect('/')
    password = request.POST['password']    
    pw_hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()    
    print(pw_hash)          
    
    new_user = User.objects.create(first_name=request.POST['first_name'], last_name=request.POST['last_name'], email=request.POST['email'], password=pw_hash)
    request.session['user_id'] = new_user.id
    return redirect('/success')

def login(request):
    errors = User.objects.login_validator(request.POST)
    if errors:
        for key, value in errors.items():
            messages.error(request,value)
        return redirect('/')
    user = User.objects.filter(email=request.POST['login_email'])
    if user:
        logged_user = user[0]
    else:
        errors['no_user'] = "There is no user with this email"
        for key, value in errors.items():
            messages.error(request,value)
        return redirect('/')
    
    if bcrypt.checkpw(request.POST['login_password'].encode(), logged_user.password.encode()):
        request.session['user_id'] = logged_user.id
        return redirect('/success')
    else:
        errors['wrong_password'] = "That password in incorrect"
        for key, value in errors.items():
            messages.error(request,value)
        return redirect('/')
    return redirect('/')

def success(request):
    if "user_id" in request.session:
        context = {
            'logged_user': User.objects.get(id=request.session['user_id'])
        }
        return render(request, 'login.html', context)
    else:
        return redirect('/')

def delete_session(request):
    del request.session['user_id']
    return redirect('/')