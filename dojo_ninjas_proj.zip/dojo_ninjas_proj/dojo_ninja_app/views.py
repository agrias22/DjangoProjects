from django.shortcuts import render, HttpResponse, redirect
from .models import Dojo, Ninja
def index(request):
    context = {
        "dojos": Dojo.objects.all(),
    }
    return render(request, 'index.html', context)

def create_dojo(request):
    Dojo.objects.create(name=request.POST['dojo_name'], city=request.POST['dojo_city'], state = request.POST['dojo_state'], desc='default')
    return redirect('/')

def create_ninja(request):
    print('X)X)X)X)X)X)X)X)X)X)X)')
    print(request.POST['dojo_select'])
    dojo = Dojo.objects.get(name=request.POST['dojo_select'])
    Ninja.objects.create(dojo =dojo, first_name=request.POST['ninja_name'], last_name=request.POST['ninja_last'])
    return redirect('/')

def delete_dojo(request):
    dojo = Dojo.objects.get(name=request.POST['dojo_delete'])
    dojo.delete()
    return redirect('/')