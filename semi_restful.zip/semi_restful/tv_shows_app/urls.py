from django.urls import path     
from . import views
urlpatterns = [
    path('shows/new', views.index),
    path('shows/create', views.create_show),
    path('shows/<int:num>', views.show_info), 
    path('shows', views.all_show),
    path('shows/<int:num>/edit', views.edit_show), 
    path('shows/<int:num>/edit_show', views.confirm_edit),
    path('shows/<int:num>/delete', views.delete_show),
]