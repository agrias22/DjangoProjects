from django.shortcuts import render, HttpResponse, redirect
from . models import Show

def index(request):
    return render(request, 'new_show.html')

def create_show(request):
    tv_show = Show.objects.create(
            title=request.POST['tv_title'], 
            network=request.POST['tv_network'], 
            release_date=request.POST['tv_date'], 
            desc=request.POST['tv_desc'])
    num = tv_show.id
    return redirect(str('/shows/') + str(num))

def show_info(request, num):
    context = {
        'some_show' : Show.objects.get(id=num)
    }
    return render(request, 'show_info.html', context)

def all_show(request):
    context = {
        'all_shows' : Show.objects.all()
    }
    return render(request, 'all_shows.html', context)

def edit_show(request, num):
    context = {
        'some_show': Show.objects.get(id=num)
    }
    return render(request, 'edit_show.html', context)

def confirm_edit(request, num):
    tv_show = Show.objects.get(id= request.POST['tv_id'])
    tv_show.title = request.POST['tv_title']
    tv_show.network = request.POST['tv_network']
    tv_show.release_date= request.POST['tv_date']
    tv_show.desc = request.POST['tv_desc']
    tv_show.save()

    return redirect(str('/shows/') + str(tv_show.id))

def delete_show(request, num):
    tv_show =  Show.objects.get(id = num)
    tv_show.delete()
    return redirect('/shows')